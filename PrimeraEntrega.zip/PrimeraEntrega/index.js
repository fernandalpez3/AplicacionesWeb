var fileManager = require('./fileManager');
const fileName = __dirname + '/data/temp.txt';
const NodeCache = require( "node-cache" );
const myCache = new NodeCache();
fileManager.createNewFile(fileName);

let jsonObject = {
    reservations : [
        {
            restaurantName: "Save",
            restaurant_id : 1,
            user_reserved_id: 1,
            reserved : true,
            active : true
        }
    ],
    resultCode : 200
};
fileManager.saveJsonObjectToFile(jsonObject,fileName);
